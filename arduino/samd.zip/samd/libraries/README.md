# Third-Party Libraries
* [Adafruit BusIO](https://github.com/adafruit/Adafruit_BusIO)
* [Adafruit GFX](https://github.com/adafruit/Adafruit-GFX-Library)
* [Adafruit SSD1306](https://github.com/adafruit/Adafruit_SSD1306)
* [Adafruit NeoPixel](https://github.com/adafruit/Adafruit_NeoPixel)
* [Arduino WiFi101](https://github.com/arduino-libraries/WiFi101) (WINC1500)
* [Arduino ECCX08](https://github.com/arduino-libraries/ArduinoECCX08)
* [Arduino BearSSL](https://github.com/arduino-libraries/ArduinoBearSSL)
* [SparkFun SCD30](https://github.com/sparkfun/SparkFun_SCD30_Arduino_Library)
